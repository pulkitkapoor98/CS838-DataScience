# Stage 1

For this project, we used names of any kind of educational institutions including universities, colleges, schools and schools of universities. We extracted approx 300 recent articles from The New York Times (https://www.nytimes.com/topic/subject/colleges-and-universities) which were related to universities and colleges. The occurrences of these entity were marked manually by enclosing them with a keyword- pair <uname></uname>. For eg: <uname>University Name</uname>.

The page contains links to the the following items - 

1. Set I - Training Set of 200 documents
2. Set J -  Testing Set of 107 documents
3. src - Codebase for the project
4. docs - Set of all the marked up documents

