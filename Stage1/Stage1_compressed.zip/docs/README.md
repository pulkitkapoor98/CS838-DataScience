# Marked up documents

This page contains a set of 307 marked up documents. For this project, we used names of any kind of educational institutions including universities, colleges, schools and schools of universities. The occurrences of these entity were marked manually by enclosing them with a keyword- pair <uname></uname>. For eg: <uname>University Name</uname>.
